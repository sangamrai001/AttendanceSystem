import numpy as np
import matplotlib.pyplot as plt
from math import comb

# Define x[n] and h[n]
def x(n):
    return comb(3*n, n) * ((1/9)**n) if n >= 0 and n <= 44 else 0

h = [-1, 2, 1, -2]

# Initialize parameters
N = 16
L = N - len(h) + 1
M = len(h) - 1

output = np.zeros(44+M)

# Perform overlap-and-save
for i in range(0, 45, L):
    # Extract segment of x[n]
    x_segment = [x(n) for n in range(i, i+N)]
    
    # Pad x_segment with zeros
    x_segment += [0] * M
    
    # Perform convolution
    y = np.convolve(x_segment, h, mode='full')
    
    # Add to output
    output[i:i+len(y)-1] += y[:len(y)-1]

# Plot the output sequence
plt.stem(range(len(output)), output, use_line_collection=True)
plt.title('Output Sequence')
plt.xlabel('n')
plt.ylabel('y[n]')
plt.show()
