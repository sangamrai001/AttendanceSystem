import numpy as np
import matplotlib.pyplot as plt
import math

def binomial_coefficient(n, k):
    return math.comb(n, k)

def dft(x):
    return np.fft.fft(x)

def idft(X):
    return np.fft.ifft(X)

def overlap_and_save(x, h, N):
    M = len(h)
    L = N - M + 1

    # Step 2: Apply zero-padding to h[n]
    h_padded = np.pad(h, (0, N - M), mode='constant')

    # Step 3: Initialize y[n]
    y = np.zeros(len(x) + len(h) - 1)

    # Step 4: Iterate through blocks
    for i in range(0, len(x), L):
        x_block = x[i:i+L]
        x_block_padded = np.pad(x_block, (0, M - 1), mode='constant')
        
        # Step 5: Compute DFT
        X = dft(x_block_padded)
        H = dft(h_padded)[:len(x_block_padded)]  # Adjust length of H
        Y = X * H
        
        # Step 6: Take inverse DFT
        y_block = idft(Y)
        
        # Add to y[n]
        y[i:i+len(y_block)] += y_block.real

    return y[:len(x) + len(h) - 1]

# Define the sequences
n_x = np.arange(45)
x = [binomial_coefficient(3*n, n) * (1/9)**n for n in n_x]

h = np.array([-1, 2, 1, -2])

# Define block size for DFT
N = 16

# Compute convolution
y = overlap_and_save(x, h, N)

# Plot the output sequence
plt.plot(n_x, y)
plt.xlabel('n')
plt.ylabel('y[n]')
plt.title('Output Sequence')
plt.show()
