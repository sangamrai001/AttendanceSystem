import face_recognition
import cv2
import numpy as np
import csv 
import os
from datetime import datetime

#taking input from the webcam
video_capture = cv2.VideoCapture(0)

#importing photos from the dataset 
#encoding for gettig raw data of the faces
robert_images = face_recognition.load_image_file("D:/MONSOON sem 23/independentpro/dataset/robert.png")
robert_encoding = face_recognition.face_encodings(robert_images)[0]

timlin_images = face_recognition.load_image_file("D:/MONSOON sem 23/independentpro/dataset/timlin.png")
timlin_encoding = face_recognition.face_encodings(timlin_images)[0]

chris_images = face_recognition.load_image_file("D:/MONSOON sem 23/independentpro/dataset/chris.png")
chris_encoding = face_recognition.face_encodings(chris_images)[0]

thor_images = face_recognition.load_image_file("D:/MONSOON sem 23/independentpro/dataset/thor.png")
thor_encoding = face_recognition.face_encodings(thor_images)[0]

known_face_encoding =  [timlin_encoding , chris_encoding , thor_encoding , robert_encoding]
known_faces_names = [  "timlin" , "chris" , "thor", "robert"] 
students = known_faces_names.copy() 

face_locations = [] #for storing face location in the frame if there is any face coming from video capture like cordinates
face_encodings = [] #raw data
face_names = [] #name of the face if it is present 
s = True


# for date and time 
now = datetime.now()
current_date = now.strftime("%Y-%m-%d")

#for opening csv file

f = open(current_date +'.csv' ,'w+' , newline='')
lnwriter = csv.writer(f)

while True:#ifinte loop
    _,frame = video_capture.read() #reading the video data input
    small_frame = cv2.resize(frame,(0,0),fx=0.25 , fy = 0.25) #decresing the size of the input
    # rgb_small_frame = np.ascontiguousarray(frame[:, :, ::-1])
    rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
    
    if s:
       #if there is any any face in the frame these two variables will store the data
       face_locations = face_recognition.face_locations(rgb_small_frame)#for the detection of the face in the frame or not
       face_encodings = face_recognition.face_encodings(rgb_small_frame ,face_locations)#store the face data of the coming frame
       face_names = []
       for face_encoding in face_encodings:
           matches = face_recognition.compare_faces(known_face_encoding , face_encoding)#compariing
           name =""
           face_distance = face_recognition.face_distance(known_face_encoding,face_encoding)
           best_match_index = np.argmin(face_distance)#best probability of the face match
           if matches[best_match_index]:
                name = known_faces_names[best_match_index]#name of the face that we have just recognized
                face_names.append(name)
           if name in known_faces_names:
               if name in students:
                   students.remove(name)
                   print(students)
                   current_time = now.strftime("%H-%M-%S")
                   lnwriter.writerow([name,current_time])
    cv2.imshow("attendance system" , frame)
    if cv2.waitKey(1) & 0xFF==ord('q'):
        break
video_capture.release()
cv2.destroyAllWindows()
f.close()
