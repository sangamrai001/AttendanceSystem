import numpy as np
import scipy as sc
import matplotlib.pyplot as plt
from scipy import fft
from scipy import signal
from scipy import special


x=np.zeros(55)
for i in range(45):
    if i==0:
         x[i] = 1
    else:
         x[i]= special.binom(3*i, i)*(1/9)**i

h = np.array([-1, 2, 1, -2], dtype=np.complex128)

z = np.zeros(shape=(4,16), dtype=np.complex128)

for i in range(4):
    if i==0:
       for j in range(16):
           if j<3:
              z[i][j] = 0
           else:
              z[i][j] = x[i*13+j-3]
    else:
       for j in range(16):
           z[i][j] = x[i*13+j-3]


h = np.append(h, np.zeros(12))
h = fft.fft(h)



for i in range(4):
    z[i] = fft.fft(z[i])
    z[i] = np.multiply(z[i],h)
    z[i] = fft.ifft(z[i])

y =  np.zeros(52, dtype=np.complex128)

for i in range(52):
    y[i] = z[i//13][i%13+3]

plt.stem(y)
plt.xlabel('n')
plt.ylabel('x[n]*h[n]')
plt.grid(linestyle='dashed')

plt.show()
