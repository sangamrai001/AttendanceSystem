import os
import face_recognition


def encode_images_in_folder(folder_path):
    # Create lists to store face encodings and corresponding image paths
    face_encodings = []
    image_path = []
    print("Encoding test images..................")
    # Loop through files in the folder
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)

        # Check if the file is an image (you can add more image formats if needed)
        if file_path.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
            try:
                # Load the image using face_recognition
                image = face_recognition.load_image_file(file_path)

                # Find face encodings in the image
                face_encoding = face_recognition.face_encodings(image)

                if len(face_encoding) > 0:
                    # If a face is found, store the face encoding and image path
                    face_encodings.append(face_encoding[0])
                    image_path.append(file_path)

            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
    print("encodings generated..................")
    return face_encodings
