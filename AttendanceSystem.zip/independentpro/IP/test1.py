import face_recognition
from PIL import Image, ImageDraw
import os
from datetime import datetime
import random

def face_extract(group_photo_path):
    group_image = face_recognition.load_image_file(group_photo_path)
    face_locations = face_recognition.face_locations(group_image)

    print("Extracting faces from group photo...")

    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d")
    output_dir = current_date

    os.makedirs(output_dir, exist_ok=True)

    with Image.open(group_photo_path) as image:
        draw = ImageDraw.Draw(image)
        for i, face_location in enumerate(face_locations):
            top, right, bottom, left = face_location

            # Extract the face from the group photo
            face_image = group_image[top:bottom, left:right]

            # Convert the NumPy array to a Pillow image
            face_pillow_image = Image.fromarray(face_image)

            # Generate a random identifier for the extracted face
            random_identifier = random.randint(1000, 9999)

            # Save the extracted face in the output directory
            output_path = os.path.join(output_dir, f"{current_date}_{random_identifier}_{i + 1}.jpg")
            face_pillow_image.save(output_path)

    print("Face extraction done.")
    return output_dir
