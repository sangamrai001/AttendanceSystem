import csv
from datetime import datetime

# Get the current date
current_date = datetime.now().strftime('%Y-%m-%d')
csv_file = f'{current_date}.csv'

# Assuming you have these variables already defined
# matched_indexes, roll_no, roll_no2

# Open the existing CSV file in read mode
with open(csv_file, 'r') as file:
    # Create a CSV reader
    reader = csv.reader(file)

    # Convert the CSV content to a list of lists
    rows = list(reader)

# Open the CSV file in write mode
with open(csv_file, 'w', newline='') as file:
    # Create a CSV writer
    writer = csv.writer(file)

    # Iterate through the rows
    for i in range(len(rows)):
        roll_number = rows[i][0]  # Assuming roll number is in the first column

        if i < len(matched_indexes) and matched_indexes[i] != -1:
            present = roll_no[matched_indexes[i]]
            writer.writerow([roll_number, present, "Present"])
        else:
            writer.writerow([roll_number, "Absent"])

print("Attendance marked successfully.................")
