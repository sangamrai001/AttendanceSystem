import face_recognition

def find_best_matches(test_encodings, dataset_encodings, tolerance):
    matched_indexes = []

    for i, test_encoding in enumerate(test_encodings):
        best_match = -1
        best_distance = tolerance + 1

        for j, dataset_encoding in enumerate(dataset_encodings):
            is_match = face_recognition.compare_faces([test_encoding], dataset_encoding, tolerance=0.1)
            if is_match[0] and best_distance > tolerance:
                best_match = j
                best_distance = tolerance

        matched_indexes.append(best_match)

    return matched_indexes
