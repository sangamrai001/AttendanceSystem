import face_recognition
from PIL import Image, ImageDraw
import os

# Step 1: Read the file with images
# Assuming all images are in a directory called 'images'
image_dir = 'images'
image_files = [os.path.join(image_dir, f) for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f)) and f.lower().endswith(('.png', '.jpg', '.jpeg'))]

# Rest of your code remains the same...
# Step 2: Define your face extraction function
def extract_faces(group_photo_path, i):
    group_image = face_recognition.load_image_file(group_photo_path)

    # Find all face locations in the group photo
    face_locations = face_recognition.face_locations(group_image)

    # Create a directory to store the extracted faces
    output_dir = "dataset"
    os.makedirs(output_dir, exist_ok=True)

    # Load the group photo as a Pillow image for drawing
    image = Image.open(group_photo_path)
    draw = ImageDraw.Draw(image)

    # Loop through the face locations and extract each face
    for i1, face_location in enumerate(face_locations):
        top, right, bottom, left = face_location

        # Extract the face from the group photo
        face_image = group_image[top:bottom, left:right]

        # Convert the NumPy array to a Pillow image
        face_pillow_image = Image.fromarray(face_image)

        # Save the extracted face in the output directory
        if i < 9:
            output_path = os.path.join(output_dir, f"202110{i+1}.jpg")
            i += 1
        else:
            output_path = os.path.join(output_dir, f"20211{i+1}.jpg")
            i += 1
        face_pillow_image.save(output_path)
    return i

i = 0
for image_file in image_files:
    i = extract_faces(image_file, i)
    print(image_files)
