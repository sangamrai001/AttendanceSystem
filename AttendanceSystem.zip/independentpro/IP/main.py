from test import *
from test1 import *
from matcher import *
from attend import *
from rollno import *
import numpy as np
# this is the test timage we are using
test_image = "/Users/sangamrai/Desktop/This PC/MONSOON SEM23/independentpro/IP/images/images.jpeg"

folder_name = face_extract(test_image)
encodings = encode_images_in_folder(folder_name)

# Initialize empty arrays for odd and even lines
odd_lines = []
even_lines = []

# Open the file in read mode
file_path = 'dataset_encodings.txt'  # Replace with the path to your file
try:
    with open(file_path, 'r') as file:
        # Initialize a line counter
        line_number = 1

        # Iterate through each line in the file
        for line in file:
            # Determine if the current line is odd or even
            if line_number % 2 == 1:
                odd_lines.append(line.strip())
            else:
                even_lines.append(line.strip())

            # Increment the line counter
            line_number += 1
except FileNotFoundError:
    print(f"File '{file_path}' not found.")
except Exception as e:
    print(f"An error occurred: {str(e)}")

roll_no = [int(element) for element in odd_lines]
roll_no2 = roll_no.copy()
encoding = []
for i in range(len(even_lines)):
    elements = even_lines[i].strip('[]').split(',')
    float_array = np.array([float(element.strip()) for element in elements])
    encoding.append(float_array)

matched_indexes = find_best_matches(encodings, encoding, tolerance=0.5)
print(matched_indexes)
roll()
#
date_1 = '2023-9-167fwe'
attend(roll_no, matched_indexes, date_1)
