import face_recognition

def comparefaces(image1_path, image2_path):
    # Load the images and encode the faces
    image1 = face_recognition.load_image_file(image1_path)
    image2 = face_recognition.load_image_file(image2_path)

    face_encoding1 = face_recognition.face_encodings(image1)[0]
    face_encoding2 = face_recognition.face_encodings(image2)[0]

    # Compare the face encodings
    results = face_recognition.compare_faces([face_encoding1], face_encoding2)

    return results[0]

# Paths to the images you want to compare
image1_path = "/Users/sangamrai/Desktop/This PC/MONSOON SEM23/independentpro/IP/dataset/2021102.png"  # Replace with the actual path of your first image
image2_path = "/Users/sangamrai/Desktop/This PC/MONSOON SEM23/independentpro/IP/images/images.jpeg"  # Replace with the actual path of your second image

# Compare the faces
is_same_person = comparefaces(image1_path, image2_path)

if is_same_person:
    print("These are images of the same person.")
else:
    print("These are images of different people.")
