import face_recognition
from PIL import Image, ImageDraw
import os

# Load the group photo
group_photo_path = "D:/MONSOON sem 23/independentpro/test.jpg"  # Change to the actual file path of your group photo
group_image = face_recognition.load_image_file(group_photo_path)

# Find all face locations in the group photo
face_locations = face_recognition.face_locations(group_image)

# Create a directory to store the extracted faces
output_dir = "extracted_faces"
os.makedirs(output_dir, exist_ok=True)

# Load the group photo as a Pillow image for drawing
image = Image.open(group_photo_path)
draw = ImageDraw.Draw(image)

# Loop through the face locations and extract each face
for i, face_location in enumerate(face_locations):
    top, right, bottom, left = face_location

    # Extract the face from the group photo
    face_image = group_image[top:bottom, left:right]

    # Convert the NumPy array to a Pillow image
    face_pillow_image = Image.fromarray(face_image)

    # Save the extracted face in the output directory
    output_path = os.path.join(output_dir, f"extracted_face_{i+1}.jpg")
    face_pillow_image.save(output_path)

    # Display the extracted face
    #face_pillow_image.show()

# Close the group photo
image.close()
