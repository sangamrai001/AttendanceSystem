import numpy as np

def find_best_matches(dataset_encodings,test_encodings, tolerance=0.2):
    matched_indexes = []

    for i, test_encoding in enumerate(test_encodings):
        best_match = -1
        best_distance = tolerance + 1

        for j, dataset_encoding in enumerate(dataset_encodings):
            distance = np.linalg.norm([a - b for a, b in zip(test_encoding, dataset_encoding)])

            if distance <= tolerance and distance < best_distance:
                best_match = j
                best_distance = distance

        matched_indexes.append(best_match)

    return matched_indexes

dataset_encodings = [[3,21,1 ], [3,4,5] ,[34 ,2 ,24],[45 ,453 ,35345 , 335544]]
testing_encodings = [[3,4,5],[3,21,1 ],[33 ,33,333],[7788]]
matched_indexes = find_best_matches(testing_encodings, dataset_encodings, tolerance=0.2)

print("Matched Indexes:", matched_indexes)
