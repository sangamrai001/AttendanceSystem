import face_recognition
import numpy as np
import csv 
import os
from datetime import datetime

#importing photos from the dataset 
#encoding for gettig raw data of the faces

# output_dir = "D:\MONSOON sem 23\independentpro\extracted_faces"
# known_face_encoding = []
# known_faces_names = []

# for i in range(17):
#     image_path = os.path.join(output_dir, f"extracted_face_{i+1}.jpg")
#     name = f"extracted_face_{i+1}"
#     face = face_recognition.load_image_file(image_path)
#     face_encoding = face_recognition.face_encodings(face)[0]
#     known_face_encoding.append(face_encoding)
#     known_faces_names.append(name)

# students = known_faces_names.copy()
# # for date and time 
# now = datetime.now()
# current_date = now.strftime("%Y-%m-%d")

# f = open(current_date +'.csv' ,'w+' , newline='')
# lnwriter = csv.writer(f)


# face_locations = [] #for storing face location in the frame if there is any face coming from video capture like cordinates
# face_encodings = [] #raw data
# face_names = [] #name of the face if it is present 


# # for date and time 
# now = datetime.now()
# current_date = now.strftime("%Y-%m-%d")

#for opening csv file

# f = open(current_date +'.csv' ,'w+' , newline='')
# lnwriter = csv.writer(f)
# # Load the group photo
# group_photo_path = "D:/MONSOON sem 23/independentpro/test.jpg"  # Change to the actual file path of your group photo
# group_image = face_recognition.load_image_file(group_photo_path)


# known_faces =[]

# for date and time 
now = datetime.now()
current_date = now.strftime("%Y-%m-%d")

# #for opening csv file

f = open(current_date +'.csv' ,'w+' , newline='')
lnwriter = csv.writer(f)

# # Load the group image
group_image_path = "D:/MONSOON sem 23/independentpro/test.jpg"
group_image = face_recognition.load_image_file(group_image_path)

# Find face locations in the group image
face_locations = face_recognition.face_locations(group_image)

# Load the dataset
dataset_path = "D:\MONSOON sem 23\independentpro\extracted_faces"
dataset = []
student = [] 
for filename in os.listdir(dataset_path):
    if filename.endswith(".jpg"):
        image_path = os.path.join(dataset_path, filename)
        image = face_recognition.load_image_file(image_path)
        dataset.append((filename, face_recognition.face_encodings(image)[0]))
        student.append(filename)
        
empty_set = set()
# Compare the faces
for filename, encoding in dataset:
    for face_location in face_locations:
        top, right, bottom, left = face_location
        face_encoding = face_recognition.face_encodings(group_image, [face_location])[0]
        
        # Compare the face encodings
        results = face_recognition.compare_faces([encoding], face_encoding,tolerance=0.4)
        
        if results[0]:
            empty_set.add(filename)
            
for se in empty_set:
    current_time = now.strftime("%H-%M-%S")
    lnwriter.writerow([se,current_time]) 
    

# for j in range(17):
#     face_image_encoding = face_recognition.face_encodings(group_image)[i]
#     for face_encoding in face_encodings:
#            matches = face_recognition.compare_faces(known_face_encoding , face_encoding)#compariing
#            name =""
#            face_distance = face_recognition.face_distance(known_face_encoding,face_encoding)
#            best_match_index = np.argmin(face_distance)#best probability of the face match
#            if matches[best_match_index]:
#                 name = known_faces_names[best_match_index]#name of the face that we have just recognized
#                 face_names.append(name)
#            if name in known_faces_names:
#                if name in students:
#                    students.remove(name)
#                    print(students)
#                    current_time = now.strftime("%H-%M-%S")
#                    lnwriter.writerow([name,current_time])
   
#         matches = face_recognition.compare_faces(known_face_encoding , face_image_encoding)#compariing
#         face_distance = face_recognition.face_distance(known_face_encoding,face_image_encoding)
#         best_match_index = np.argmin(face_distance)#best probability of the face match
#         known_faces.append()

# stuknown = known_faces.copy()

# while stuknown:
#     stuknown.pop(0) 
#     for i in 17:
#         for j in 17:
#             if()



# while True:#ifinte loop
    
#     if s:
#        #if there is any any face in the frame these two variables will store the data
#        face_locations = face_recognition.face_locations(rgb_small_frame)#for the detection of the face in the frame or not
#        face_encodings = face_recognition.face_encodings(rgb_small_frame ,face_locations)#store the face data of the coming frame
#        face_names = []
#        for face_encoding in face_encodings:
#            matches = face_recognition.compare_faces(known_face_encoding , face_encoding)#compariing
#            name =""
#            face_distance = face_recognition.face_distance(known_face_encoding,face_encoding)
#            best_match_index = np.argmin(face_distance)#best probability of the face match
#            if matches[best_match_index]:
#                 name = known_faces_names[best_match_index]#name of the face that we have just recognized
#                 face_names.append(name)
#            if name in known_faces_names:
#                if name in students:
#                    students.remove(name)
#                    print(students)
#                    current_time = now.strftime("%H-%M-%S")
#                    lnwriter.writerow([name,current_time])
#     cv2.imshow("attendance system" , frame)
#     if cv2.waitKey(1) & 0xFF==ord('q'):
#         break
# video_capture.release()
# cv2.destroyAllWindows()
# f.close()
