import numpy  as np

def mat(testi , datas):
    for i in testi:
        min = []
        best = -1
        bestmat = 1+.2
        for j in datas:
            diff = abs(np.j-np.i)
            if diff<=.2 & diff<bestmat:
                best = j
                bestmat = diff
        min.append(best)
    return min


testi = [[3,2,1],[3,34,3]]
datas = [[3,2,1] , [3,34,3]]
res = mat(testi , datas)
print(res)
