from datetime import datetime
import csv


# for date and time
now = datetime.now()
current_date = now.strftime("%Y-%m-%d")

#for opening csv file

f = open(current_date +'.csv' ,'w+' , newline='')
lnwriter = csv.writer(f)

current_time = now.strftime("%H-%M-%S")
lnwriter.writerow([present,"Present"])

for i in range(len(roll_no2)):
    lnwriter.writerow([roll_no2[i],"Absent"])

